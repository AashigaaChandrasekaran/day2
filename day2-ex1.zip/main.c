#include <stdio.h>
#include <string.h>
int romanToInt(char *s) {
    int result = 0;
    int prevValue = 0;
    
    for (int i = strlen(s) - 1; i >= 0; i--) {
        int currentValue;
        
        switch(s[i]) {
            case 'I':
                currentValue = 1;
                break;
            case 'V':
                currentValue = 5;
                break;
            case 'X':
                currentValue = 10;
                break;
            case 'L':
                currentValue = 50;
                break;
            case 'C':
                currentValue = 100;
                break;
            case 'D':
                currentValue = 500;
                break;
            case 'M':
                currentValue = 1000;
                break;
            default:
                printf("INVALID");
        }
        if (currentValue < prevValue) {
            result -= currentValue;
        }
        else {
            result += currentValue;
        }
        
        prevValue = currentValue;
    }
    
    return result;
}

int main() {
    char romanNumeral[100] ;
    int count;
    printf("COUNT:");
    scanf("%d",&count);
    for(int a=1;a<=count;a++){
        printf("ROMAN VALUE:");
        scanf("%s",romanNumeral);
        int result = romanToInt(romanNumeral);
        printf("\n%d\n", result);
    }
    return 0;
}
