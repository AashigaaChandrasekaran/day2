#include<stdio.h>
#include<string.h>
int main()
{
    int i,j;
    char str[100]="TheQuickBrownFox";
        int col = 4;
        int row = 0;
        if(strlen(str) %col == 0)
        row= strlen(str) / col;
        else
        row= strlen(str) / col + 1;
        char charArr[row][col];
        int k = 0;
        for(i=0 ;i<row ; i++)
        {
    for(j=0;j<col;j++)
    if(k<strlen(str))
    charArr[i][j]=str[k++];        
    else          
        charArr[i][j] = ' ';
        }
        for(i=0 ; i<row ; i++){
            for(j=0 ; j<col ; j++){
                printf("%c",charArr[i][j] + " ");
            }printf("\n");
}
return 0;
}