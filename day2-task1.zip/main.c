#include <stdio.h>

void findNeighbors(int arr[], int n, int key) {
    int i, left, right;
    for (i = 0; i < n; i++) {
        if (arr[i] == key) {
            left = (i > 0) ? arr[i - 1] : -1;
            right = (i < n - 1) ? arr[i + 1] : -1;
            printf("LEFT: %d ]RIGHT: %d\n", left, right);
            return;
        }
    }
    printf("INVALID KEY\n");
}

int main() {
    int input_array[] = {2, 55, 7, 8, 0, 11, 44};
    int key;
    printf("Enter the key: ");
    scanf("%d", &key);
    findNeighbors(input_array, sizeof(input_array) / sizeof(input_array[0]), key);
    return 0;
}
