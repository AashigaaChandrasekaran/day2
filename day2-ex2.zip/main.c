#include<stdio.h>

int main(){
    int n, arr[20];
    scanf("%d",&n);
    for(int i=0;i<=n;i++){
        scanf("%d",arr[i])
    }
}