//matrix formation using string
/*example:
i/p:s="WELCOME TO ALL"
    col= 3
o/p:
    matrix
    WEL
    COM
    ETO
    ALL
*/
